import 'package:flutter/material.dart';
import 'package:chat/home_page.dart';
import 'package:chat/chat_interface.dart';

void main() => runApp(new MyApp());

class MyApp extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return new MaterialApp(
      title: "Chat",
      home: new HomePage()
    );
  }
}